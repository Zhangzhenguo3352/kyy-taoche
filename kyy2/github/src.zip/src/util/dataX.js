
export const inItdata =  {
  aa: 1,
  drawerShow: false,
  http: 'https://quickappapi.taoche.com/get',
  http3Car: 'https://quickappapi.taoche.com/get?entry=taocheapp',
  carData: 'https://quickappapi.taoche.com/phone/brand.json',
  v2: '7.1.0',
  v: '7.1.1',
  header: {
    appuk: '',// 由设备激活（UV统计）接口返回
    devicetoken: '',//设备唯一标识符(为了防止和其他app重复，加quick后缀，如868403026561511quick)
    signature: '',//暂时不传
    csource: '',//OPPO 来源自哪个渠道(从快应用接口获取)
    appid: '',//app.quickapp
    timestamp: ''//1528276526458
  },
  listIndex: true
}